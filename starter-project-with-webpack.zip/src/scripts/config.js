const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  API_KEY: '',
  BASE_IMAGE_URL: 'https://story-api.dicoding.dev/images/',
  DEFAULT_LANGUAGE: 'id-ID',
  MAP_TILER_KEY: 'Hclc5398dWQcaqYqgE1P',
};

export default CONFIG;